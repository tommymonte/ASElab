#include "common.h"

void sharedFunction(void){
	
}
