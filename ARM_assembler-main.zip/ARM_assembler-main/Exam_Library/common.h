extern int sharedVariable;
